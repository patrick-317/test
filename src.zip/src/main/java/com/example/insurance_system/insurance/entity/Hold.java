package com.example.insurance_system.insurance.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Hold {
    private int customerID;
}
