package com.example.insurance_system.insurance.repository;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ComplaintMapper {
}
