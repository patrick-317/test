package com.example.insurance_system.insurance.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Underwriting {
    private int customerID;
}
